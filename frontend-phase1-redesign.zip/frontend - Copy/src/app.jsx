import { useEffect, useState } from 'react'

import Header from './components/header'
import Sidebar from './components/sidebar'
import ChannelCard from './components/channelCard'
import Player from './components/player'

import Login from './pages/login'
import Register from './pages/register'

import {
  getChannels,
  searchChannels,
  getBestStream,
  getCurrentUser,
  getFavorites,
  addFavorite,
  removeFavorite,
  logout
} from './services/Api'

function App() {
  /* =========================
     AUTH STATE
  ========================= */

  const [user, setUser] = useState(null)

  const [authLoading, setAuthLoading] =
    useState(true)

  const [authPage, setAuthPage] =
    useState('login')

  /* =========================
     CHANNEL STATE
  ========================= */

  const [channels, setChannels] =
    useState([])

  const [selectedCountry, setSelectedCountry] =
    useState('NG')

  const [search, setSearch] =
    useState('')

  const [loading, setLoading] =
    useState(false)

  const [error, setError] =
    useState(null)

  /* =========================
     STREAM STATE
  ========================= */

  const [stream, setStream] =
    useState(null)

  const [playingChannel, setPlayingChannel] =
    useState(null)

  /* =========================
     FAVORITES
  ========================= */

  const [favorites, setFavorites] =
    useState([])

  /* =========================
     CHECK LOGIN
  ========================= */

  useEffect(() => {
    async function checkAuthentication() {
      const token =
        localStorage.getItem('token')

      if (!token) {
        setAuthLoading(false)
        return
      }

      try {
        const result =
          await getCurrentUser()

        setUser(result.data || result.user)
      } catch (error) {
        console.error(
          'Authentication check failed:',
          error
        )

        logout()
        setUser(null)
      } finally {
        setAuthLoading(false)
      }
    }

    checkAuthentication()
  }, [])

  /* =========================
     LOAD FAVORITES
  ========================= */

  useEffect(() => {
    if (!user) {
      return
    }

    async function loadFavorites() {
      try {
        const result =
          await getFavorites()

        /*
         * Depending on your backend,
         * result.data may be an array
         * of favorite documents.
         */

        const favoriteData =
          result.data || []

        setFavorites(favoriteData)
      } catch (error) {
        console.error(
          'Unable to load favorites:',
          error
        )
      }
    }

    loadFavorites()
  }, [user])

  /* =========================
     LOAD CHANNELS
  ========================= */

  async function loadChannels(country) {
    try {
      setLoading(true)
      setError(null)

      const result =
        await getChannels(country)

      setChannels(result.data || [])
    } catch (error) {
      console.error(error)

      if (error.status === 401) {
        handleLogout()
        return
      }

      setError(
        'Unable to load channels.'
      )
    } finally {
      setLoading(false)
    }
  }

  /* =========================
     SEARCH
  ========================= */

  async function handleSearch() {
    if (!search.trim()) {
      loadChannels(selectedCountry)
      return
    }

    try {
      setLoading(true)
      setError(null)

      const result =
        await searchChannels(search)

      setChannels(result.data || [])
    } catch (error) {
      console.error(error)

      setError(
        'Unable to search channels.'
      )
    } finally {
      setLoading(false)
    }
  }

  /* =========================
     PLAY CHANNEL
  ========================= */

  async function handlePlay(channel) {
    if (!user) {
      setAuthPage('login')
      return
    }

    try {
      setError(null)

      setPlayingChannel(channel)

      const result =
        await getBestStream(channel.id)

      if (!result.data) {
        setError(
          'No playable stream found for this channel.'
        )

        setPlayingChannel(null)

        return
      }

      setStream(result.data)
    } catch (error) {
      console.error(error)

      if (error.status === 401) {
        handleLogout()
        return
      }

      setError(
        'Unable to load the channel stream.'
      )

      setPlayingChannel(null)
    }
  }

  /* =========================
     FAVORITE CHECK
  ========================= */

 function isFavorite(channelId) {
  return favorites.some(favorite => {
    const id =
      typeof favorite === 'string'
        ? favorite
        : favorite.channelId || favorite.channel

    return id === channelId
  })
}

  /* =========================
     ADD / REMOVE FAVORITE
  ========================= */

  async function handleFavorite(channel) {
    if (!user) {
      setAuthPage('login')
      return
    }

    const alreadyFavorite =
      isFavorite(channel.id)

    try {
      setError(null)

     if (alreadyFavorite) {
  await removeFavorite(channel.id)

  setFavorites(current =>
    current.filter(favorite => {
      const id =
        typeof favorite === 'string'
          ? favorite
          : favorite.channelId || favorite.channel

      return id !== channel.id
    })
  )
}  else {
  const result =
    await addFavorite(channel.id)

  /*
   * Backend returns the complete
   * favorites array.
   */
  if (Array.isArray(result.data)) {
    setFavorites(result.data)
  } else {
    setFavorites(current => [
      ...current,
      channel.id
    ])
  }
}
    } catch (error) {
      console.error(error)

      if (error.status === 401) {
        handleLogout()
        return
      }

      setError(
        'Unable to update favorite.'
      )
    }
  }

  /* =========================
     CLOSE PLAYER
  ========================= */

  function closePlayer() {
    setStream(null)
    setPlayingChannel(null)
  }

  /* =========================
     CHANGE COUNTRY
  ========================= */

  function changeCountry(country) {
    setSelectedCountry(country)
    setSearch('')

    loadChannels(country)
  }

  /* =========================
     LOGIN SUCCESS
  ========================= */

  function handleLogin(userData) {
    setUser(userData)

    setAuthLoading(false)
  }

  /* =========================
     REGISTER SUCCESS
  ========================= */

  function handleRegister(userData) {
    /*
     * If registration returned
     * a token, the user is already
     * authenticated.
     */

    if (userData) {
      setUser(userData)
      setAuthLoading(false)
      return
    }

    /*
     * Otherwise send them to
     * the login screen.
     */

    setAuthPage('login')
  }

  /* =========================
     LOGOUT
  ========================= */

  function handleLogout() {
    logout()

    setUser(null)
    setFavorites([])
    setStream(null)
    setPlayingChannel(null)
    setChannels([])

    setAuthPage('login')
  }

  /* =========================
     INITIAL CHANNEL LOAD
  ========================= */

  useEffect(() => {
    if (!user) {
      return
    }

    loadChannels('NG')
  }, [user])

  /* =========================
     AUTH LOADING SCREEN
  ========================= */

  if (authLoading) {
    return (
      <div className="auth-page">
        <div className="message">
          Checking authentication...
        </div>
      </div>
    )
  }

  /* =========================
     LOGIN / REGISTER
  ========================= */

  if (!user) {
    if (authPage === 'register') {
      return (
        <Register
          onRegister={handleRegister}
          onSwitchToLogin={() =>
            setAuthPage('login')
          }
        />
      )
    }

    return (
      <Login
        onLogin={handleLogin}
        onSwitchToRegister={() =>
          setAuthPage('register')
        }
      />
    )
  }

  /* =========================
     MAIN APPLICATION
  ========================= */

  return (
    <div className="app">
      <Header
        search={search}
        setSearch={setSearch}
        onSearch={handleSearch}
        user={user}
        onLogout={handleLogout}
      />

      <div className="layout">
        <Sidebar
  selectedCountry={selectedCountry}
  onCountryChange={changeCountry}
  favorites={favorites}
  channels={channels}
  onFavoriteSelect={handlePlay}
/>

        <main className="content">
          <div className="content-header">
            <div>
              <p className="eyebrow">
                LIVE TELEVISION
              </p>

              <h2>
                {search
                  ? `Search results for "${search}"`
                  : selectedCountry === 'NG'
                    ? 'Nigerian Channels'
                    : 'Live Channels'}
              </h2>
            </div>

            <div className="channel-count">
              {channels.length} channels
            </div>
          </div>

          {loading && (
            <div className="message">
              Loading channels...
            </div>
          )}

          {error && (
            <div className="error">
              {error}
            </div>
          )}

          {!loading &&
            !error &&
            channels.length === 0 && (
              <div className="message">
                No channels found.
              </div>
            )}

          <div className="channel-grid">
            {channels.map(channel => (
              <ChannelCard
                key={channel.id}
                channel={channel}
                onPlay={handlePlay}
                isFavorite={isFavorite(
                  channel.id
                )}
                onFavorite={
                  handleFavorite
                }
              />
            ))}
          </div>
        </main>
      </div>

      {stream && (
        <Player
          stream={stream}
          onClose={closePlayer}
        />
      )}
    </div>
  )
}

export default App