function ChannelCard({
  channel,
  onPlay,
  isFavorite,
  onFavorite
}) {
  function handleFavorite(event) {
    event.stopPropagation()

    onFavorite(channel)
  }

  return (
    <div className="channel-card">

      <button
        className="channel-play"
        onClick={() => onPlay(channel)}
      >
        <div className="channel-logo">
          <span>
            {channel.name?.charAt(0) || '?'}
          </span>
        </div>

        <div className="channel-info">
          <h3>
            {channel.name}
          </h3>

          <p>
            {channel.country || 'Unknown'}
          </p>
        </div>
      </button>

      <button
        className={`favorite-button ${
          isFavorite ? 'favorite-active' : ''
        }`}
        onClick={handleFavorite}
        aria-label={
          isFavorite
            ? 'Remove from favorites'
            : 'Add to favorites'
        }
      >
        {isFavorite ? '★' : '☆'}
      </button>

    </div>
  )
}

export default ChannelCard