function Header({
  search,
  setSearch,
  onSearch,
  user,
  onLogout
}) {
  function handleSubmit(event) {
    event.preventDefault()
    onSearch()
  }

  const displayName =
    user?.name ||
    user?.username ||
    user?.email?.split('@')[0] ||
    'Account'

  const initial = displayName.charAt(0).toUpperCase()

  return (
    <header className="header">
      <div className="brand">
        <div className="brand-icon" aria-hidden="true">
          ▶
        </div>

        <div className="brand-copy">
          <div className="brand-name">STREAMTV</div>
          <span>Live television, anywhere.</span>
        </div>
      </div>

      <form
        className="search"
        onSubmit={handleSubmit}
        role="search"
      >
        <span className="search-icon" aria-hidden="true">
          ⌕
        </span>

        <input
          type="text"
          placeholder="Search channels..."
          value={search}
          onChange={event =>
            setSearch(event.target.value)
          }
          aria-label="Search channels"
        />

        <kbd>Enter</kbd>
      </form>

      <div className="header-account">
        <div className="account-copy">
          <span className="account-greeting">SIGNED IN</span>
          <strong>{displayName}</strong>
        </div>

        <div className="account-avatar" aria-hidden="true">
          {initial}
        </div>

        <button
          type="button"
          className="logout-button"
          onClick={onLogout}
          title="Log out"
        >
          Logout
        </button>
      </div>
    </header>
  )
}

export default Header
