import { useEffect, useRef } from 'react'
import Hls from 'hls.js'

function Player({ stream, onClose }) {
  const videoRef = useRef(null)

  useEffect(() => {
    if (!stream?.url || !videoRef.current) {
      return
    }

    const video = videoRef.current

    const url =
      `http://localhost:2000/api/streams/proxy?url=${encodeURIComponent(
        stream.url
      )}`

    let hls

    if (Hls.isSupported()) {
      hls = new Hls()

      hls.loadSource(url)
      hls.attachMedia(video)

      hls.on(
        Hls.Events.MANIFEST_PARSED,
        () => {
          video.play().catch(() => {})
        }
      )

      hls.on(
        Hls.Events.ERROR,
        (_, data) => {
          console.error(
            'HLS playback error:',
            data
          )
        }
      )
    } else if (
      video.canPlayType(
        'application/vnd.apple.mpegurl'
      )
    ) {
      video.src = url

      video.addEventListener(
        'loadedmetadata',
        () => {
          video.play().catch(() => {})
        },
        { once: true }
      )
    } else {
      video.src = url
    }

    return () => {
      if (hls) {
        hls.destroy()
      }

      video.removeAttribute('src')
      video.load()
    }
  }, [stream])

  if (!stream) {
    return null
  }

  return (
    <div className="player-overlay">
      <div className="player-container">
        <div className="player-header">
          <div>
            <span className="live-dot" />
            LIVE
          </div>

          <button
            className="close-button"
            onClick={onClose}
          >
            ✕
          </button>
        </div>

        <video
          ref={videoRef}
          className="video-player"
          controls
          playsInline
        />

        <div className="player-info">
          <h2>{stream.title}</h2>

          {stream.quality && (
            <span>
              {stream.quality}
            </span>
          )}
        </div>
      </div>
    </div>
  )
}

export default Player