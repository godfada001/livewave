const countries = [
  { code: 'NG', name: 'Nigeria', flag: '🇳🇬' },
  { code: 'US', name: 'United States', flag: '🇺🇸' },
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧' },
  { code: 'CA', name: 'Canada', flag: '🇨🇦' },
  { code: 'FR', name: 'France', flag: '🇫🇷' },
  { code: 'DE', name: 'Germany', flag: '🇩🇪' },
  { code: 'IN', name: 'India', flag: '🇮🇳' }
]

function Sidebar({
  selectedCountry,
  onCountryChange,
  favorites,
  channels,
  onFavoriteClick,
  onRemoveFavorite
}) {
  /*
   * Favorites stored in MongoDB are channel IDs.
   *
   * Match those IDs against the channels we
   * already have loaded from the IPTV API.
   */
  const favoriteChannels = channels.filter(channel =>
    favorites.includes(channel.id)
  )

  return (
    <aside className="sidebar">

      {/* =========================
          FAVORITES
      ========================= */}

      <div className="sidebar-title">
        MY FAVORITES
      </div>

      {favoriteChannels.length === 0 ? (
        <div className="sidebar-empty">
          <span>☆</span>
          <p>No favorite channels yet.</p>
          <small>
            Click the star on a channel to add it here.
          </small>
        </div>
      ) : (
        <div className="favorites-list">
          {favoriteChannels.map(channel => (
            <div
              key={channel.id}
              className="favorite-item"
            >
              <button
                className="favorite-channel"
                onClick={() =>
                  onFavoriteClick(channel)
                }
              >
                <div className="favorite-logo">
                  {channel.name?.charAt(0) || '?'}
                </div>

                <span className="favorite-name">
                  {channel.name}
                </span>
              </button>

              <button
                className="favorite-remove"
                onClick={() =>
                  onRemoveFavorite(channel)
                }
                title="Remove from favorites"
              >
                ★
              </button>
            </div>
          ))}
        </div>
      )}

      {/* =========================
          COUNTRIES
      ========================= */}

      <div className="sidebar-title countries-title">
        COUNTRIES
      </div>

      <button
        className={
          selectedCountry === ''
            ? 'country active'
            : 'country'
        }
        onClick={() =>
          onCountryChange('')
        }
      >
        <span>🌎</span>
        <span>All Countries</span>
      </button>

      {countries.map(country => (
        <button
          key={country.code}
          className={
            selectedCountry === country.code
              ? 'country active'
              : 'country'
          }
          onClick={() =>
            onCountryChange(country.code)
          }
        >
          <span>{country.flag}</span>
          <span>{country.name}</span>
        </button>
      ))}
    </aside>
  )
}

export default Sidebar